"""Regression tests for task-aware cloud provider selection and bounded failover."""
from __future__ import annotations

import json
import types

import pytest

from celina_pkg import config, provider_router, router


class FakeResponse:
    def __init__(self, status_code=200, body=None, headers=None):
        self.status_code = status_code
        self._body = body or {"choices": [{"message": {"role": "assistant", "content": "ok"}}]}
        self.headers = headers or {}
        self.closed = False

    def close(self):
        self.closed = True

    def json(self):
        return self._body

    def raise_for_status(self):
        if self.status_code >= 400:
            exc = router.requests.exceptions.HTTPError(f"HTTP {self.status_code}")
            exc.response = types.SimpleNamespace(status_code=self.status_code)
            raise exc

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()

    def iter_lines(self, decode_unicode=True):
        yield 'data: {"choices":[{"delta":{"content":"ok"}}]}'
        yield "data: [DONE]"


@pytest.fixture(autouse=True)
def clean_provider_state(monkeypatch):
    provider_router.reset_state_for_tests()
    for key in ("GROQ_API_KEY", "GEMINI_API_KEY", "NVIDIA_API_KEY", "MISTRAL_API_KEY", "CEREBRAS_API_KEY", "OPENROUTER_API_KEY"):
        monkeypatch.setattr(config, key, "", raising=False)
    monkeypatch.delenv("CELINA_PROVIDER_ORDER", raising=False)
    yield
    provider_router.reset_state_for_tests()


def test_task_ranking_prefers_gemini_for_documents(monkeypatch):
    monkeypatch.setattr(config, "GEMINI_API_KEY", "test-gemini")
    monkeypatch.setattr(config, "GROQ_API_KEY", "test-groq")
    candidates = provider_router.candidates("Summarize this PDF document", "fast")
    assert [p.name for p, _ in candidates] == ["gemini", "groq"]


def test_provider_status_never_exposes_api_keys(monkeypatch):
    monkeypatch.setattr(config, "GROQ_API_KEY", "do-not-print-this-secret")
    status = provider_router.status()
    assert next(x for x in status if x["name"] == "groq")["configured"] is True
    assert "do-not-print-this-secret" not in json.dumps(status)


def test_http_429_fails_over_immediately_and_records_provider(monkeypatch):
    monkeypatch.setattr(config, "GROQ_API_KEY", "groq-secret")
    monkeypatch.setattr(config, "GEMINI_API_KEY", "gemini-secret")
    monkeypatch.setenv("CELINA_PROVIDER_ORDER", "groq,gemini")
    obj = object.__new__(router.CelinaRouter)
    calls = []

    def fake_post(self, url, payload, timeout, headers=None, retries=3, stream=False):
        calls.append((url, payload["model"], timeout, headers["Authorization"]))
        if len(calls) == 1:
            return FakeResponse(429, headers={"Retry-After": "10"})
        return FakeResponse(200)

    obj._post_with_retry = types.MethodType(fake_post, obj)
    result = obj._post_openrouter([{"role": "user", "content": "hello"}], "fast", use_tools=False)
    assert result["_celina_provider"] == "gemini"
    assert result["_celina_model"] == "gemini-2.5-flash"
    assert [x[0] for x in calls] == [
        "https://api.groq.com/openai/v1/chat/completions",
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    ]
    assert calls[0][2] <= 12
    assert calls[0][3] == "Bearer groq-secret"
    assert next(x for x in provider_router.status() if x["name"] == "groq")["cooldown_seconds"] > 0


def test_no_keys_returns_empty_cloud_candidates():
    assert provider_router.candidates("hello", "fast") == []


def test_failover_attempt_count_is_bounded_to_three(monkeypatch):
    for name in ("GROQ_API_KEY", "GEMINI_API_KEY", "NVIDIA_API_KEY", "MISTRAL_API_KEY"):
        monkeypatch.setattr(config, name, "configured")
    obj = object.__new__(router.CelinaRouter)
    calls = []

    def fail_post(self, url, payload, timeout, headers=None, retries=3, stream=False):
        calls.append(url)
        return FakeResponse(429)

    obj._post_with_retry = types.MethodType(fail_post, obj)
    with pytest.raises(RuntimeError, match="All configured cloud providers failed"):
        obj._post_openrouter([{"role": "user", "content": "hello"}], "fast", use_tools=False)
    assert len(calls) == 3

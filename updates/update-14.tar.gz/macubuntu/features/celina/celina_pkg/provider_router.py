"""Task-aware OpenAI-compatible cloud provider selection for Celina.

Keeps provider routing deterministic and dependency-light. Secrets are read from
config at call time; status output never returns their values.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
import threading
import time
from typing import Any


@dataclass(frozen=True)
class Provider:
    name: str
    endpoint: str
    key_attr: str
    model_env: str
    default_model: str


PROVIDERS: tuple[Provider, ...] = (
    Provider("groq", "https://api.groq.com/openai/v1/chat/completions", "GROQ_API_KEY", "CELINA_GROQ_MODEL", "llama-3.3-70b-versatile"),
    Provider("gemini", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "GEMINI_API_KEY", "CELINA_GEMINI_MODEL", "gemini-2.5-flash"),
    Provider("nvidia", "https://integrate.api.nvidia.com/v1/chat/completions", "NVIDIA_API_KEY", "CELINA_NVIDIA_MODEL", "meta/llama-3.3-70b-instruct"),
    Provider("mistral", "https://api.mistral.ai/v1/chat/completions", "MISTRAL_API_KEY", "CELINA_MISTRAL_MODEL", "mistral-small-latest"),
    Provider("cerebras", "https://api.cerebras.ai/v1/chat/completions", "CEREBRAS_API_KEY", "CELINA_CEREBRAS_MODEL", "llama-3.3-70b"),
    Provider("openrouter", "https://openrouter.ai/api/v1/chat/completions", "OPENROUTER_API_KEY", "CELINA_OPENROUTER_MODEL", "openrouter/free"),
)

# Preferred order can be overridden for deployments/tests using comma-separated
# provider names. Unknown and unconfigured entries are ignored.
_LOCK = threading.Lock()
_COOLDOWN_UNTIL: dict[str, float] = {}
_LAST_FAILURE: dict[str, str] = {}


def _key(provider: Provider) -> str:
    from . import config
    return str(getattr(config, provider.key_attr, "") or "").strip()


def configured(provider: Provider) -> bool:
    key = _key(provider)
    return bool(key and key != "PASTE_YOUR_KEY_HERE")


def model_for(provider: Provider) -> str:
    return os.environ.get(provider.model_env, "").strip() or provider.default_model


def _rank(prompt: str, gear: str) -> list[str]:
    override = os.environ.get("CELINA_PROVIDER_ORDER", "").strip()
    if override:
        raw = [p.strip().lower() for p in override.split(",") if p.strip()]
    else:
        low = prompt.lower()
        if any(x in low for x in ("pdf", "document", "image", "screenshot", "vision", "long file", "multi-file")):
            raw = ["gemini", "nvidia", "groq", "mistral", "cerebras", "openrouter"]
        elif gear == "deep" or any(x in low for x in ("architecture", "reason", "analyze", "debug", "security audit", "compare")):
            raw = ["nvidia", "gemini", "groq", "mistral", "cerebras", "openrouter"]
        elif any(x in low for x in ("code", "python", "script", "json", "function")):
            raw = ["mistral", "nvidia", "gemini", "groq", "cerebras", "openrouter"]
        else:
            raw = ["groq", "cerebras", "gemini", "mistral", "nvidia", "openrouter"]
    # With no explicit order, only configured cloud credentials are attempted.
    seen: set[str] = set()
    ordered = [name for name in raw if name in {p.name for p in PROVIDERS} and not (name in seen or seen.add(name))]
    return ordered


def candidates(prompt: str, gear: str) -> list[tuple[Provider, str]]:
    now = time.monotonic()
    rank = _rank(prompt, gear)
    by_name = {p.name: p for p in PROVIDERS}
    result: list[tuple[Provider, str]] = []
    with _LOCK:
        cooldowns = dict(_COOLDOWN_UNTIL)
    for name in rank:
        p = by_name[name]
        if configured(p) and cooldowns.get(name, 0.0) <= now:
            result.append((p, _key(p)))
    # If every configured provider is cooling down, allow the soonest one again
    # rather than forcing an immediate local downgrade or permanent lockout.
    if not result:
        for name in rank:
            p = by_name[name]
            if configured(p):
                result.append((p, _key(p)))
    return result


def mark_failure(name: str, reason: str, retry_after: float = 0.0) -> None:
    now = time.monotonic()
    # A modest bounded cooldown prevents hot-looping a rate-limited service.
    cooldown = min(max(retry_after, 15.0), 300.0)
    with _LOCK:
        _COOLDOWN_UNTIL[name] = now + cooldown
        _LAST_FAILURE[name] = reason[:120]


def mark_success(name: str) -> None:
    with _LOCK:
        _COOLDOWN_UNTIL.pop(name, None)
        _LAST_FAILURE.pop(name, None)


def status() -> list[dict[str, Any]]:
    now = time.monotonic()
    with _LOCK:
        cooldowns, failures = dict(_COOLDOWN_UNTIL), dict(_LAST_FAILURE)
    rows = []
    for p in PROVIDERS:
        key_ok = configured(p)
        until = cooldowns.get(p.name, 0.0)
        rows.append({"name": p.name, "configured": key_ok, "model": model_for(p),
                     "cooldown_seconds": max(0, int(until - now)),
                     "last_error": failures.get(p.name, "")})
    return rows


def reset_state_for_tests() -> None:
    with _LOCK:
        _COOLDOWN_UNTIL.clear()
        _LAST_FAILURE.clear()
